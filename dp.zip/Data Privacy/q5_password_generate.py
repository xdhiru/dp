import random

def open_dictionary(file):
    with open(file, 'r') as dict:
        return dict.read().splitlines()

def generate_password(wordbank, num):
    selected_words = []
    for _ in range(num):
        selected_words.append(random.choice(wordbank))

    password = ''.join(selected_words)
    return password

wordbank1 = open_dictionary("dictionary.txt")
password1 = generate_password(wordbank1, 5)
print("Generated password:", password1)