import hashlib
import requests

def check_password(password):
    hashed = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    first5 = hashed[:5]
    rest = hashed[5:]
    
    url = f"https://api.pwnedpasswords.com/range/{first5}"
    response = requests.get(url)
    
    if response.status_code != 200:
        print(f"Error: Unable to connect to the API. Status code: {response.status_code}")
        return 0
    
    for line in response.text.splitlines():
        hash_suffix, count = line.split(':')
        if hash_suffix == rest:
            return int(count)
    
    return 0

def load_passwords(file_name):
    with open(file_name, 'r') as f:
        return [line.strip().split(',') for line in f]

def main():
    credentials = load_passwords('HIBP_credentials.txt')
    
    for user, password in credentials:
        result = check_password(password)
        if result > 0:
            print(f"Alert: {user}'s password has been found {result} times in data breaches!")
        else:
            print(f"Good news: {user}'s password is safe.")

if __name__ == "__main__":
    main()
