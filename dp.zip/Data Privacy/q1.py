def caesar_cipher(text, shift, encrypt):
    result = ""
    if not encrypt:
        shift = -shift
    
    for char in text:
        if char.isalpha():
            base = 'a' if char.islower() else 'A'
            shifted = (ord(char) - ord(base) + shift) % 26
            result += chr(shifted + ord(base))
        else:
            result += char
    
    return result

def main():
    text = input("Enter secret message: ")
    shift = int(input("Enter shift value: "))
    choice = input("Encrypt or Decrypt? (E/D): ").strip().upper()
    encrypt = choice == 'E'
    
    result = caesar_cipher(text, shift, encrypt)
    print("Result:", result)

if __name__ == "__main__":
    main()
