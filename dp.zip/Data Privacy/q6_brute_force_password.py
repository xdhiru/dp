import time

letters = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '=', '+'
]

def next_try(trial):
    for i in range(len(trial) - 1, -1, -1):
        if trial[i] != letters[-1]:
            nxt = letters[letters.index(trial[i]) + 1]
            b = trial[:i]
            a = trial[i + 1:]
            return b + nxt + a
        trial = trial[:i] + letters[0] + trial[i + 1:]
    return letters[0] * (len(trial) + 1)

def crack(pwd):
    start = time.time()
    trial = letters[0]
    while len(trial) <= len(pwd):
        if trial == pwd:
            end = time.time()
            return trial, end - start
        trial = next_try(trial)
    return None, None

pwd1 = "Ez1"                  # 3 letters = 76^3 combinations = 438976     # My PC Should be able to crack this.
pwd2 = "4kay"                 # 4 letters = 76^3 combinations = 33362176   # Should stil be fine?
pwd3 = "BruteForceThis9000!"  # 19 letters = 76^18 combinations = 7155577026378634231908944079486976   # I don't feel so good...

cracked_pwd1, time_taken1 = crack(pwd1)
print("Cracked password: ",cracked_pwd1)
print("Time taken: ",time_taken1," seconds")

cracked_pwd2, time_taken2 = crack(pwd2)
print("Cracked password: ",cracked_pwd2)
print("Time taken: ",time_taken2," seconds")

# DangerZone : PC can't compute as the password is too long!!
#cracked_pwd3, time_taken3 = crack(pwd3)
#print("Cracked password: ",cracked_pwd3)
#print("Time taken: ",time_taken3," seconds")