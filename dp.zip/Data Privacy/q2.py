def encrypt_rail_fence(text, key):
    rails = [['\n' for _ in range(len(text))] for _ in range(key)]
    direction = 1
    row = 0

    for i in range(len(text)):
        rails[row][i] = text[i]
        row += direction
        if row == key - 1 or row == 0:
            direction *= -1

    ciphertext = ''.join([rails[i][j] for i in range(key) for j in range(len(text)) if rails[i][j] != '\n'])
    return ciphertext

def decrypt_rail_fence(ciphertext, key):
    rails = [['\n' for _ in range(len(ciphertext))] for _ in range(key)]
    direction = 1
    row = 0

    for i in range(len(ciphertext)):
        rails[row][i] = '*'
        row += direction
        if row == key - 1 or row == 0:
            direction *= -1

    index = 0
    for r in range(key):
        for c in range(len(ciphertext)):
            if rails[r][c] == '*':
                rails[r][c] = ciphertext[index]
                index += 1

    plaintext = []
    row = 0
    direction = 1
    for i in range(len(ciphertext)):
        plaintext.append(rails[row][i])
        row += direction
        if row == key - 1 or row == 0:
            direction *= -1

    return ''.join(plaintext)

plaintext = "Never try to fake hardwork"
key = 2
print("Plain Text:", plaintext)

ciphertext = encrypt_rail_fence(plaintext, key)
print("Ciphertext:", ciphertext)

decrypted_text = decrypt_rail_fence(ciphertext, key)
print("Decrypted Text:", decrypted_text)
